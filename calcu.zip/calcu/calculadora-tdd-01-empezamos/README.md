# Calculadora-TDD
Este es un tutorial para aprender a iniciarse en Python a través de TDD. Para esto, vamos a usar el ejemplo típico de para empezar, una calculadora.
